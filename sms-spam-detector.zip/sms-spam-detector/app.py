from flask import Flask, render_template, request
import pickle
import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import string
import os

# Create Flask app
app = Flask(__name__)

# Download necessary NLTK data
nltk.download('stopwords')
nltk.download('punkt')

# Text preprocessing function
def preprocess_text(text):
    # Convert to lowercase
    text = text.lower()

    # Remove punctuation
    text = ''.join([char for char in text if char not in string.punctuation])

    # Tokenize
    tokens = nltk.word_tokenize(text)

    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    tokens = [word for word in tokens if word not in stop_words]

    # Stemming
    stemmer = PorterStemmer()
    tokens = [stemmer.stem(word) for word in tokens]

    # Join the tokens back into a single string
    return ' '.join(tokens)

# Load the model and vectorizer
try:
    # Load the model and vectorizer
    model = pickle.load(open('spam-sms-mnb-model.pkl', 'rb'))
    cv = pickle.load(open('cv-transform.pkl', 'rb'))
    print("Model and vectorizer loaded successfully!")
except Exception as e:
    print(f"Error loading model or vectorizer: {e}")
    print("Will try to load when first request is received.")
    model = None
    cv = None

# Ensure model is loaded
def ensure_model_loaded():
    global model, cv
    if model is None or cv is None:
        try:
            model = pickle.load(open('spam-sms-mnb-model.pkl', 'rb'))
            cv = pickle.load(open('cv-transform.pkl', 'rb'))
            print("Model and vectorizer loaded successfully!")
        except Exception as e:
            print(f"Error loading model or vectorizer: {e}")
            return False
    return True

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        message = request.form['message']

        if not message:
            return render_template('result.html', prediction='Error', message='Please enter a message')

        # Ensure model is loaded
        if not ensure_model_loaded():
            return render_template('result.html', prediction='Error', message='Model could not be loaded. Please check if model files exist.')

        try:
            # Preprocess the message
            processed_message = preprocess_text(message)

            # Vectorize the message
            vectorized_message = cv.transform([processed_message]).toarray()

            # Make prediction
            prediction = model.predict(vectorized_message)

            # Get prediction probability
            prediction_proba = model.predict_proba(vectorized_message)
            confidence = prediction_proba[0][1] if prediction[0] == 1 else prediction_proba[0][0]
            confidence_str = f"{confidence:.2%}"

            # Return result
            if prediction[0] == 1:
                return render_template('result.html', prediction='Spam', message=message, confidence=confidence_str)
            else:
                return render_template('result.html', prediction='Not Spam', message=message, confidence=confidence_str)
        except Exception as e:
            return render_template('result.html', prediction='Error', message=f'An error occurred: {e}')

@app.route('/about')
def about():
    return render_template('spam.html')

if __name__ == '__main__':
    # Create a port variable for Heroku deployment
    port = int(os.environ.get('PORT', 5000))
    # Run the app
    app.run(host='0.0.0.0', port=port, debug=True)
