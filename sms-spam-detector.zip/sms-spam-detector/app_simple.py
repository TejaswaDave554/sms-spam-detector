try:
    from flask import Flask, render_template, request
    import pickle
    import numpy as np
    import nltk
    from nltk.corpus import stopwords
    from nltk.stem import PorterStemmer
    import string
    import os

    # Flag for successful imports
    IMPORTS_SUCCESSFUL = True
except ImportError as e:
    print(f"Error importing modules: {e}")
    print("Please install the required modules using: pip install flask numpy nltk")
    IMPORTS_SUCCESSFUL = False

# Simple HTML response for missing modules
MISSING_MODULES_HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Missing Modules</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            line-height: 1.6;
            background-color: #f8f9fa;
        }
        h1 { color: #e74c3c; }
        code {
            background-color: #f5f5f5;
            padding: 2px 5px;
            border-radius: 3px;
            font-family: monospace;
        }
        .box {
            background-color: white;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="box">
        <h1>Missing Required Modules</h1>
        <p>The SMS Spam Detector requires several Python modules that are not currently installed:</p>
        <ul>
            <li><code>flask</code> - Web framework</li>
            <li><code>numpy</code> - Numerical computing</li>
            <li><code>pandas</code> - Data analysis</li>
            <li><code>nltk</code> - Natural language processing</li>
            <li><code>scikit-learn</code> - Machine learning</li>
        </ul>
        <h2>Installation Instructions</h2>
        <p>Install the required modules using pip:</p>
        <code>pip install flask numpy pandas scikit-learn nltk</code>
        <p>Download NLTK data:</p>
        <code>python -m nltk.downloader stopwords punkt</code>
        <p>Then run the application again:</p>
        <code>python app.py</code>
    </div>
</body>
</html>
"""

# Only continue if imports were successful
if IMPORTS_SUCCESSFUL:
    # Create Flask app
    app = Flask(__name__)

    # Download necessary NLTK data
    try:
        nltk.download('stopwords')
        nltk.download('punkt')
    except Exception as e:
        print(f"Error downloading NLTK data: {e}")

    # Text preprocessing function
    def preprocess_text(text):
        # Convert to lowercase
        text = text.lower()

        # Remove punctuation
        text = ''.join([char for char in text if char not in string.punctuation])

        # Tokenize
        tokens = nltk.word_tokenize(text)

        # Remove stopwords
        stop_words = set(stopwords.words('english'))
        tokens = [word for word in tokens if word not in stop_words]

        # Stemming
        stemmer = PorterStemmer()
        tokens = [stemmer.stem(word) for word in tokens]

        # Join the tokens back into a single string
        return ' '.join(tokens)

    # Load the model and vectorizer
    try:
        # Load the model and vectorizer
        model = pickle.load(open('spam-sms-mnb-model.pkl', 'rb'))
        cv = pickle.load(open('cv-transform.pkl', 'rb'))
        print("Model and vectorizer loaded successfully!")
    except Exception as e:
        print(f"Error loading model or vectorizer: {e}")
        print("You need to train the model first by running the Jupyter notebook.")
        model = None
        cv = None

    # Ensure model is loaded
    def ensure_model_loaded():
        global model, cv
        if model is None or cv is None:
            try:
                model = pickle.load(open('spam-sms-mnb-model.pkl', 'rb'))
                cv = pickle.load(open('cv-transform.pkl', 'rb'))
                print("Model and vectorizer loaded successfully!")
            except Exception as e:
                print(f"Error loading model or vectorizer: {e}")
                return False
        return True

    # Routes
    @app.route('/')
    def home():
        if ensure_model_loaded():
            return render_template('index.html')
        else:
            return render_template('model_missing.html')

    @app.route('/predict', methods=['POST'])
    def predict():
        if request.method == 'POST':
            message = request.form['message']

            if not message:
                return render_template('result.html', prediction='Error', message='Please enter a message')

            # Ensure model is loaded
            if not ensure_model_loaded():
                return render_template('result.html', prediction='Error', message='Model could not be loaded. Please check if model files exist.')

            try:
                # Preprocess the message
                processed_message = preprocess_text(message)

                # Vectorize the message
                vectorized_message = cv.transform([processed_message]).toarray()

                # Make prediction
                prediction = model.predict(vectorized_message)

                # Get prediction probability
                prediction_proba = model.predict_proba(vectorized_message)
                confidence = prediction_proba[0][1] if prediction[0] == 1 else prediction_proba[0][0]
                confidence_str = f"{confidence:.2%}"

                # Return result
                if prediction[0] == 1:
                    return render_template('result.html', prediction='Spam', message=message, confidence=confidence_str)
                else:
                    return render_template('result.html', prediction='Not Spam', message=message, confidence=confidence_str)
            except Exception as e:
                return render_template('result.html', prediction='Error', message=f'An error occurred: {e}')

    @app.route('/about')
    def about():
        return render_template('spam.html')

    if __name__ == '__main__':
        # Create a port variable for Heroku deployment
        port = int(os.environ.get('PORT', 5000))
        # Run the app
        app.run(host='0.0.0.0', port=port, debug=True)
else:
    # Simple HTTP server for missing modules error message
    try:
        import http.server
        import socketserver

        class SimpleHandler(http.server.SimpleHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200)
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                self.wfile.write(MISSING_MODULES_HTML.encode())

        PORT = 5000
        print(f"\nStarting simple server on port {PORT} to display missing modules information.")
        print("Please install the required modules and restart the application.")

        with socketserver.TCPServer(("", PORT), SimpleHandler) as httpd:
            print(f"Server running at http://localhost:{PORT}")
            httpd.serve_forever()
    except Exception as e:
        print(f"Error starting simple server: {e}")
        print(MISSING_MODULES_HTML)
