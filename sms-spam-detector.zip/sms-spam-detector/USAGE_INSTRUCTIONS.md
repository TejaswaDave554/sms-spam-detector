# SMS Spam Detector - Usage Instructions

This SMS Spam Detector project provides several ways to detect spam messages depending on your environment and requirements.

## Quick Start (No Dependencies)

If you're in an environment with limited access to libraries, you can use our standalone solution:

1. Run the simple training and test script:
   ```
   python3 simple_spam_detector.py
   ```
   This will:
   - Create a sample dataset of spam and non-spam messages
   - Train a Naive Bayes classifier
   - Save the model to `simple_spam_model.pkl`
   - Allow you to interactively test messages

2. Test a set of predefined messages with the trained model:
   ```
   python3 test_messages.py
   ```
   This will run a series of test messages through the model and show the predictions.

## Full Solution (With Dependencies)

For a complete solution with a web interface, follow these steps:

1. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Train the model using the provided Jupyter notebook:
   ```
   jupyter notebook Spam_Detection_Using_NLP.ipynb
   ```
   Run all cells in the notebook to:
   - Load and analyze the dataset
   - Preprocess the text data
   - Train the Multinomial Naive Bayes model
   - Save the model and vectorizer for use in the web app

3. Run the Flask web application:
   ```
   python3 app.py
   ```
   This will start a web server at http://localhost:5000 where you can:
   - Enter messages through a web interface
   - Get predictions with confidence scores
   - Learn about SMS spam detection

## Alternative Solutions

If the full solution isn't working due to dependency issues, you can:

1. Use the simplified Flask app:
   ```
   python3 app_simple.py
   ```
   This script gracefully handles missing dependencies and provides instructions.

2. Use the standalone deployment script:
   ```
   python3 Spam\ SMS\ Classifier\ -\ Deployment.py
   ```
   This provides command-line prediction capabilities.

## Dataset

The model is trained on the SMS Spam Collection dataset, which contains labeled SMS messages. If you want to use your own dataset, it should be in the format:
```
ham/spam    message text
```
With one message per line, separated by a tab character.

## Model Files

The training process generates two important files:
- `spam-sms-mnb-model.pkl`: The trained Multinomial Naive Bayes model
- `cv-transform.pkl`: The CountVectorizer for text transformation

## Troubleshooting

- **Dependency issues**: If you encounter problems installing dependencies, try using the no-dependency solution with `simple_spam_detector.py`.
- **Encoding errors**: If you have problems with the dataset encoding, use the standalone solution which creates its own dataset.
- **Model loading errors**: Make sure you've trained the model before attempting to use it in the Flask app.

## Performance

The model typically achieves 97-99% accuracy on the test set. However, accuracy may vary depending on the specific dataset and preprocessing steps used.
