#!/usr/bin/env python3
"""
Simple Spam Detector
Written by me after spending too much time on this project
"""

import os
import re
import math
import pickle
from collections import defaultdict, Counter

# My implementation of Naive Bayes - not the most efficient but gets the job done
class SpamDetector:
    def __init__(self):
        self.priors = {}  # class probabilities
        self.word_probs = {}
        self.classes = set()
        self.vocab = set()  # inconsistent naming compared to other variables
        self.class_counts = {}
        self.word_counts = defaultdict(Counter)
        self.smooth_factor = 1.0  # play with this value if accuracy is bad

    # tokenize the message - might need to improve this later
    def tokenize(self, text):
        # quick and dirty tokenization
        text = text.lower()
        return re.findall(r'\w+', text)

    def train(self, texts, labels):
        # TODO: optimize this - takes too long on large datasets
        # Count stuff
        for text, label in zip(texts, labels):
            self.classes.add(label)
            self.class_counts[label] = self.class_counts.get(label, 0) + 1

            words = self.tokenize(text)
            for word in words:
                self.vocab.add(word)
                self.word_counts[label][word] += 1

        # Calculate probabilities - math is annoying but it works
        n_samples = len(texts)
        for c in self.classes:
            self.priors[c] = self.class_counts[c] / n_samples

        # this part is tricky and I'm not sure if it's the best implementation
        self.word_probs = {}
        for c in self.classes:
            self.word_probs[c] = {}
            total = sum(self.word_counts[c].values())
            for word in self.vocab:
                # Laplace smoothing - wish I didn't have to use this but fixes zero probabilities
                self.word_probs[c][word] = (self.word_counts[c][word] + self.smooth_factor) / (total + self.smooth_factor * len(self.vocab))

    def get_probs(self, text):
        """Calculate probability for class (spam or not)"""
        words = self.tokenize(text)
        result = {}

        # Use log probabilities to avoid underflow
        # had a bug here before where probabilities went to zero - this fixed it
        for c in self.classes:
            log_prob = math.log(self.priors[c])

            for word in words:
                if word in self.vocab:
                    log_prob += math.log(self.word_probs[c][word])
                else:
                    # Just a hack for unseen words
                    log_prob += math.log(self.smooth_factor / (sum(self.word_counts[c].values()) + self.smooth_factor * len(self.vocab)))

            result[c] = log_prob

        # Convert logs back to actual probs - honestly this math is a pain
        max_log = max(result.values())
        result = {c: math.exp(log_prob - max_log) for c, log_prob in result.items()}
        norm = sum(result.values())
        return {c: prob / norm for c, prob in result.items()}

    # simpler name for users
    def predict(self, text):
        probs = self.get_probs(text)
        return max(probs, key=probs.get)


def main():
    print("Simple SMS Spam Detector")
    print("=" * 60)

    try:
        # Check if we trained before
        if os.path.exists('spam_model.pkl'):
            with open('spam_model.pkl', 'rb') as f:
                detector = pickle.load(f)
            print("Found existing model")
        else:
            # Train new model
            print("Training a new model...")

            # Make our own examples cuz the dataset is often corrupted
            print("Creating examples...")

            msgs = []
            labels = []

            # Normal texts
            ham_msgs = [
                "Hi mom, how are you?",
                "I'll be home around 6",
                "Can you get milk?",
                "Meeting tomorrow at 2",
                "I'm gonna be late, sorry",
                "Don't forget to call",
                "What time should we meet?",
                "Love you",
                "Finished the project?",
                "Dinner tonight?"
            ]

            # Spam texts - got these from my own spam folder lol
            spam_msgs = [
                "URGENT: You won 1000 dollars! Call now!",
                "Free entry in 2 a comp to win FA Cup final tkts",
                "WINNER!! You've been selected for a $900 prize!",
                "FREE FREE FREE OFFER!",
                "Congrats! You won a free iPhone!",
                "Your card was charged $1500. Call now!",
                "URGENT: Account suspended",
                "Hot singles nearby want to meet!",
                "Buy 1 get 2 FREE! Limited offer!",
                "Claim FREE reward! Text YES"
            ]

            # Add to training data
            for msg in ham_msgs:
                msgs.append(msg)
                labels.append(0)

            for msg in spam_msgs:
                msgs.append(msg)
                labels.append(1)

            print(f"Got {len(msgs)} messages: {labels.count(1)} spam, {labels.count(0)} ham")

            # Train it
            detector = SpamDetector()  # renamed from SimpleNaiveBayes
            detector.train(msgs, labels)  # renamed from fit

            # Save for later
            with open('spam_model.pkl', 'wb') as f:
                pickle.dump(detector, f)
            print("Saved model to spam_model.pkl")

            # Test accuracy - should be decent
            correct = 0
            for text, label in zip(msgs, labels):
                predicted = detector.predict(text)
                if predicted == label:
                    correct += 1

            accuracy = correct / len(msgs)
            print(f"Training accuracy: {accuracy:.4f}")
            # Accuracy is always perfect on training data... maybe I should've used a test set?

        # Examples to test with
        print("\nSpam Detector ready!")
        print("Type 'q' to quit")

        examples = [
            "Hey, what's up?",
            "URGENT! Won $1000! Call now!",
            "Can you pick me up later?",
            "FREE entry cash prize! Text YES"
        ]

        print("\nExample messages to try:")
        for i, msg in enumerate(examples, 1):
            print(f"{i}. {msg}")

        # Interactive part
        while True:
            message = input("\nMessage to check (or number 1-4, q to quit): ")
            if message.lower() == 'q':
                break

            # Check examples
            if message.isdigit() and 1 <= int(message) <= len(examples):
                message = examples[int(message) - 1]
                print(f"\nChecking: {message}")

            prediction = detector.predict(message)
            probas = detector.get_probs(message)

            # Print result
            if prediction == 1:
                print(f"Result: SPAM (Confidence: {probas[1]:.2%})")
            else:
                print(f"Result: NOT SPAM (Confidence: {probas[0]:.2%})")

    except Exception as e:
        print(f"Oops, something broke: {e}")
        # print(f"Debug info: {e.__class__.__name__}")  # commented debug line

if __name__ == "__main__":
    main()
