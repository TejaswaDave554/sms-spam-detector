#!/usr/bin/env python
# coding: utf-8

# # SMS Spam Classifier - Deployment
#
# This script demonstrates how to use the trained spam classifier model directly
# without the Flask web application. It can be used for testing or integration
# with other applications.

# Import necessary libraries
import pickle
import numpy as np
import pandas as pd
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import string

# Download necessary NLTK data
nltk.download('stopwords')
nltk.download('punkt')

# Text preprocessing function
def preprocess_text(text):
    # Convert to lowercase
    text = text.lower()

    # Remove punctuation
    text = ''.join([char for char in text if char not in string.punctuation])

    # Tokenize
    tokens = nltk.word_tokenize(text)

    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    tokens = [word for word in tokens if word not in stop_words]

    # Stemming
    stemmer = PorterStemmer()
    tokens = [stemmer.stem(word) for word in tokens]

    # Join the tokens back into a single string
    return ' '.join(tokens)

# Load the model and vectorizer
try:
    # Load the model and vectorizer
    model = pickle.load(open('spam-sms-mnb-model.pkl', 'rb'))
    cv = pickle.load(open('cv-transform.pkl', 'rb'))
    print("Model and vectorizer loaded successfully!")
except Exception as e:
    print(f"Error loading model or vectorizer: {e}")
    print("Make sure you have trained the model and generated the .pkl files first.")
    model = None
    cv = None

# Function to predict if a message is spam or ham
def predict_spam(message):
    if model is None or cv is None:
        return "Error: Model or vectorizer not loaded"

    # Preprocess the message
    processed_message = preprocess_text(message)

    # Vectorize the message
    vectorized_message = cv.transform([processed_message]).toarray()

    # Make prediction
    prediction = model.predict(vectorized_message)

    # Get prediction probability
    prediction_proba = model.predict_proba(vectorized_message)

    # Return result
    if prediction[0] == 1:
        return f"Spam (Confidence: {prediction_proba[0][1]:.2f})"
    else:
        return f"Not Spam (Confidence: {prediction_proba[0][0]:.2f})"

# Example usage
if __name__ == "__main__":
    # Example messages
    test_messages = [
        "Hi mom, how are you?",
        "URGENT: You have won a 1000 prize! Call now to claim your prize.",
        "Meeting at 10am tomorrow",
        "FREE FREE FREE OFFER! Limited time only!",
        "Your credit card has been charged $1,500. If this was not you, call immediately.",
        "Can you pick up some groceries on your way home?"
    ]

    print("\n--- SMS Spam Classifier ---\n")

    if model is not None and cv is not None:
        print("Testing with example messages:\n")
        for message in test_messages:
            print(f"Message: {message}")
            print(f"Prediction: {predict_spam(message)}\n")

        # Interactive mode
        print("=" * 50)
        print("Enter your own messages (type 'exit' to quit):")

        while True:
            user_input = input("\nEnter a message: ")
            if user_input.lower() == 'exit':
                break

            print(f"Prediction: {predict_spam(user_input)}")
    else:
        print("Cannot run predictions. Please train the model first by running the Jupyter notebook.")
