#!/usr/bin/env python3
"""
Spam detector tester
Tests messages using our trained model
Last edit: 5/15/2023 - fixed a bug with loading
"""

import pickle
import os
import re
import math
from collections import defaultdict, Counter

# Need this for unpickling - can't change the structure or pickle breaks :(
class SpamDetector:
    def __init__(self):
        self.priors = {}
        self.word_probs = {}
        self.classes = set()
        self.vocab = set()
        self.class_counts = {}
        self.word_counts = defaultdict(Counter)
        self.smooth_factor = 1.0

    def tokenize(self, text):
        text = text.lower()
        return re.findall(r'\w+', text)

    def train(self, texts, labels):
        for text, label in zip(texts, labels):
            self.classes.add(label)
            self.class_counts[label] = self.class_counts.get(label, 0) + 1

            words = self.tokenize(text)
            for word in words:
                self.vocab.add(word)
                self.word_counts[label][word] += 1

        n_samples = len(texts)
        for c in self.classes:
            self.priors[c] = self.class_counts[c] / n_samples

        self.word_probs = {}
        for c in self.classes:
            self.word_probs[c] = {}
            total = sum(self.word_counts[c].values())
            for word in self.vocab:
                self.word_probs[c][word] = (self.word_counts[c][word] + self.smooth_factor) / (total + self.smooth_factor * len(self.vocab))

    def get_probs(self, text):
        words = self.tokenize(text)
        result = {}

        for c in self.classes:
            log_prob = math.log(self.priors[c])

            for word in words:
                if word in self.vocab:
                    log_prob += math.log(self.word_probs[c][word])
                else:
                    log_prob += math.log(self.smooth_factor / (sum(self.word_counts[c].values()) + self.smooth_factor * len(self.vocab)))

            result[c] = log_prob

        max_log = max(result.values())
        result = {c: math.exp(log_prob - max_log) for c, log_prob in result.items()}
        norm = sum(result.values())
        return {c: prob / norm for c, prob in result.items()}

    def predict(self, text):
        probs = self.get_probs(text)
        return max(probs, key=probs.get)

def main():
    print("Spam Detector - Test Script")
    print("=" * 50)  # less equals signs than the other script

    # Check for model file
    model_path = 'spam_model.pkl'
    if not os.path.exists(model_path):
        # Try the old filename too
        model_path = 'simple_spam_model.pkl'
        if not os.path.exists(model_path):
            print(f"Can't find any model files :(")
            print("Run the main script first to train a model")
            return

    # Load it
    try:
        with open(model_path, 'rb') as f:
            detector = pickle.load(f)
        print(f"Loaded model: {model_path}")
    except Exception as e:
        print(f"Ugh, something went wrong: {e}")
        return

    # Messages to try - some tricky ones too
    test_msgs = [
        "Hey, what's up?",
        "URGENT! Won $1000! Call now!",  # obvious spam
        "Can you pick me up later?",
        "FREE entry cash prize! Text YES",  # obvious spam
        "Meeting at 10am in conference room",
        "Get rich quick! Make money from home!",  # this one's tricky
        "Call me back pls",
        "Congrats! You won a free iPhone 15!",  # obvious spam
        "Don't forget your laptop",
        "Your account suspended. Click here."  # spam but without many spam words
    ]

    print("\nTesting these messages:")
    print("-" * 40)  # again, inconsistent with other dashes

    # Print emoji based on result - my personal touch :)
    emojis = {0: "✅", 1: "🚫"}

    for i, msg in enumerate(test_msgs, 1):
        prediction = detector.predict(msg)
        probas = detector.get_probs(msg)

        confidence = probas[prediction]
        result = "SPAM" if prediction == 1 else "OK"

        print(f"{emojis[prediction]} {i}. {msg}")
        print(f"   → {result} ({confidence:.0%} sure)")

    print("\nDone! If any look wrong, the model might need more training data.")

if __name__ == "__main__":
    main()
